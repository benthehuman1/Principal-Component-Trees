import os
import re
import numpy as np
from numpy.typing import NDArray
import pandas as pd

class NullRun:
    REGEXT_EXP = r"d(\d+)_n(\d+)\.npy"

    def __init__(self, filepath: str) -> None:
        self.filepath = filepath
        dim, n = re.findall(NullRun.REGEXT_EXP, self.filepath)[0]
        self.dim = int(dim)
        self.n = int(n)

        with open(filepath, "rb") as f:
            test_stat_values: NDArray = np.load(f)

        self.critical_values = {
            "0.05": np.quantile(test_stat_values, 1 - 0.05),
            "0.01": np.quantile(test_stat_values, 1 - 0.01),
            "0.005": np.quantile(test_stat_values, 1 - 0.005),
            "0.001": np.quantile(test_stat_values, 1 - 0.001)
        }
        del test_stat_values


class DirectionalUniformityTester:
    def __init__(self) -> None:
        pass

    def significance_test(self, X: NDArray, alpha: str) -> tuple[bool, float]:
        pass


class CachedDirectionalUniformityTester(DirectionalUniformityTester):
    def load_table(folder_path: str):
        null_files = [folder_path + short_p for short_p in os.listdir(folder_path)]
        null_runs = [NullRun(null_file) for null_file in null_files]

        table_values = []
        for null_run in null_runs:
            for alpha, cv in null_run.critical_values.items():
                val = {"Dim": null_run.dim, "N": null_run.n, "Alpha": alpha, "CriticalValue": cv}
                table_values.append(val)

        return pd.DataFrame(table_values)

    def __init__(self, test_stat_table: pd.DataFrame):
        self.test_stat_table: pd.DataFrame = test_stat_table

    def calculate_test_stat(self, X: NDArray) -> float:
        pass

    def significance_test(self, X: NDArray, alpha: str) -> tuple[bool, float]:
        given_n, given_dim = X.shape
        if given_n <= 2:
            # we don't have entries for only two data points, it's absurd.
            return False, -1
        
        table_at_given_dim = self.test_stat_table[self.test_stat_table["Dim"] == given_dim]
        if table_at_given_dim.size == 0:
            print(f"REEEE! No Table Entries for {given_dim}-D.")
            return False, -1
        
        table_at_given_alpha = table_at_given_dim[table_at_given_dim["Alpha"] == alpha]
        if table_at_given_alpha.size == 0:
            print(f"REEEE! No Table Entries for alpha={alpha}")
            return False, -1
        
        available_sample_sizes = np.sort(table_at_given_alpha["N"].values)
        next_smallest_sample_size = available_sample_sizes[np.where(available_sample_sizes <= given_n)[0].max()]        
        critical_value = table_at_given_alpha[table_at_given_alpha["N"] == next_smallest_sample_size]["CriticalValue"].values[0]
        
        observed_test_stat = self.calculate_test_stat(X)
        return observed_test_stat >= critical_value, observed_test_stat
