import numpy as np
import numpy.linalg as LA
from numpy.typing import NDArray
from uuid import uuid4
from sshaves import SharedAxisEstimator, SubspaceClusterer
from utils import random_sample, my_inv_entropy, sub_mask, mode
from dataclasses import dataclass
from queue import PriorityQueue


@dataclass(order=True)
class PrioritizedItem:
    priority: float
    item: any # SubspaceTreeNode

def node_to_priority(node):
    return PrioritizedItem(-node.resid_sum_squares, node)

class SubsapceTreeBuilder:
    def __init__(self, X: NDArray, max_shared_sample_size: int, max_sscluster_sample_size: int, shared_axis_estimator: SharedAxisEstimator, subspace_clusterer: SubspaceClusterer, y: NDArray = None, n_nodes: int = None) -> None:
        self.X = X
        self.Y = y
        self.max_shared_sample_size = max_shared_sample_size
        self.max_sscluster_sample_size = max_sscluster_sample_size
        self.shared_axis_estimator = shared_axis_estimator
        self.subspace_clusterer = subspace_clusterer
        self.n_nodes = n_nodes

    def build_tree(self):
        root = SubspaceTreeNode(None, self, np.ones(self.X.shape[0], dtype=bool))
        root_residual = root.calculate()
        queue = PriorityQueue()
        queue.put(node_to_priority(root))
        node_residuals = {}
        node_residuals[root.id] = root_residual
        curr_tree_size = 1
        while (not queue.empty()) and (curr_tree_size < self.n_nodes):
            node: SubspaceTreeNode = queue.get().item
            if node.id not in node_residuals:
                print("REE")
            node.split(node_residuals[node.id])
            del node_residuals[node.id]
            if node.left is not None:
                node_residuals[node.left.id] = node.left.calculate()
                curr_tree_size += 1
                if not node.left.is_leaf: 
                    queue.put(node_to_priority(node.left))
            if node.right is not None:
                node_residuals[node.right.id] = node.right.calculate()
                curr_tree_size += 1
                if not node.right.is_leaf: 
                    queue.put(node_to_priority(node.right))
            if node.center is not None:
                node_residuals[node.center.id] = node.center.calculate()
                curr_tree_size += 1
                if not node.center.is_leaf: 
                    queue.put(node_to_priority(node.center))

        while not queue.empty():
            node: SubspaceTreeNode = queue.get().item
            node.is_leaf = True

        return root
    
def extract_rgb(hex_color):
    rh = hex_color[1:3]
    gh = hex_color[3:5]
    bh = hex_color[5:]
    return int(rh, 16), int(gh, 16), int(bh, 16)

def weighted_avg_color(colors: list[str], weights: list):
    colors_hex = np.array([extract_rgb(clr) for clr in colors])
    clr = (colors_hex * weights[:, np.newaxis]).sum(axis=0).astype(int)
    to_hex = lambda i : str(hex(int(i))).split("x")[1]
    to_hexx = lambda h: f"{to_hex(h)}{to_hex(h)}" if len(to_hex(h)) == 1 else to_hex(h)
    return f"#{to_hexx(clr[0])}{to_hexx(clr[1])}{to_hexx(clr[2])}"

class SubspaceTreeNode:
    def __init__(self, parent, context: SubsapceTreeBuilder, mask: NDArray) -> None:
        self.parent: SubspaceTreeNode = parent
        if self.parent is not None:
            self.depth = self.parent.depth + 1
        else:
            self.depth = 1
        self.ctx = context
        self.mask = mask
        self.n_assigned: int = mask.sum()
        self.ascestral_basis: NDArray = None

        self.singular_value: float = None
        self.basis_vector: NDArray = None
        self.resid_sum_square: float = None
        
        # for whitening... remember to delete this after we no longer need it. 
        self.whitened_data_assignments: NDArray = None

        self.is_leaf: bool = False
        self.id = str(uuid4())

        self.left: SubspaceTreeNode = None
        self.center: SubspaceTreeNode = None
        self.right: SubspaceTreeNode = None

        self._setup()

    def get_descendents(self):
        result = set([self])
        if self.is_leaf:
            return result
        if self.left is not None:
            result = result.union(self.left.get_descendents())
        if self.right is not None:
            result = result.union(self.right.get_descendents())
        if self.center is not None:
            result = result.union(self.center.get_descendents())
        return result
    
    def path_to_root(self):
        result = []
        curr_node = self
        result.append(curr_node)
        while curr_node.parent is not None:
            curr_node = curr_node.parent
            result.append(curr_node)
        return result

    def _setup(self):
        self.amb_dim = self.ctx.X.shape[1]
        if self.parent is None:
            self.ascestral_basis = np.array([np.zeros(self.amb_dim)])
        else:
            self.ascestral_basis = np.vstack([self.parent.ascestral_basis, self.parent.basis_vector])

    def _projection_residuals(self, X):
        coeffs = np.dot(X, self.ascestral_basis.T)
        approx = np.dot(coeffs, self.ascestral_basis)
        return X - approx
    
    def detatch_context(self):
        self.ctx = None
        if self.left is not None:
            self.left.detatch_context()
        if self.right is not None:
            self.right.detatch_context()
        if self.center is not None:
            self.center.detatch_context()
    
    """
    def visualize(self, g: Digraph, max_sv: float, kind="svd", min_color = (1, 1, 1), max_color=(0, 0, 0)):
        if self.singular_value is None or self.resid_sum_squares is None:
            return
        
        #to_scale = lambda s: 255 - min(int((s / max_sv)*254), 254)
        to_hex = lambda t: str(hex(int(t * 254))).split("x")[1]
        to_hexx = lambda h: f"{to_hex(h)}{to_hex(h)}" if len(to_hex(h)) == 1 else to_hex(h)
        to_scale = lambda s: min(s / max_sv, 1)
        min_r, min_g, min_b = min_color
        max_r, max_g, max_b = max_color
        r_range = min_r - max_r
        g_range = min_g - max_g
        b_range = min_b - max_b
        def linterp_color(s: float):
            return (min_r - (r_range * s), min_g - (g_range * s), min_b - (b_range * s) )

        #to_hex = lambda s: str(hex(s)).split("x")[1]
        if kind == "svd":
            rt, gt, bt = linterp_color(to_scale(self.singular_value))
            line_color =  f"#{to_hexx(rt)}{to_hexx(gt)}{to_hexx(bt)}"
        if kind == "rss":
            rt, gt, bt = linterp_color(to_scale(self.resid_sum_squares))
            line_color =  f"#{to_hexx(rt)}{to_hexx(gt)}{to_hexx(bt)}"
        elif kind == "count":
            color_hex = to_hex(to_scale(self.n_assigned))
            line_color =  f"#{color_hex}{color_hex}{color_hex}"
        if kind == "class":
            #colors = ["#9eef4c", "#ffb872", "#34c1b3", "#ff0000", "#e2dc1d", "#FD9ECF", "#32a0e5", "#c60198", "#247503", "#1ed824"]
            colors = ["red","cyan", "yellow", "green", "purple", "blue"]
            dominant_class = int(mode(self.ctx.Y[self.mask]))
            line_color = colors[dominant_class]
        if kind == "class_mix":
            #colors = ["#9eef4c", "#ffb872", "#34c1b3", "#ff0000", "#e2dc1d", "#FD9ECF", "#32a0e5", "#c60198", "#247503", "#1ed824"]
            #colors = ["#00FFFF", "#FF0000", "#006400", "#FFFF00", "#800080",  "#FD9ECF", "#32a0e5", "#c60198", "#247503", "#1ed824"]
            colors = ["#0000FF", "#FF0000", "#006400", "#FFFF00", "#800080",  "#FD9ECF", "#32a0e5", "#c60198", "#247503", "#1ed824"]
            class_proportions = np.zeros(10)
            classes = self.ctx.Y[self.mask]
            for c in range(10):
                class_proportions[c] = (classes == c).sum() / len(self.ctx.Y[self.mask])
            print(class_proportions.round(2))
            line_color = weighted_avg_color(colors, class_proportions)
        if kind == "class entropy":
            inv_entropy = my_inv_entropy(self.ctx.Y[self.mask])
            color_hex = to_hex(int(inv_entropy*254))
            line_color =  f"#{color_hex}{color_hex}{color_hex}"
        g.node(self.id, "", color=line_color, fillcolor=line_color, style="filled", shape="circle")
        if self.parent is not None:
            g.edge(self.parent.id, self.id, color=line_color, penwidth="3.0", arrowhead="none")
        if self.left is not None:
            self.left.visualize(g, max_sv, kind, min_color, max_color)
        if self.right is not None:
            self.right.visualize(g, max_sv, kind, min_color, max_color)
        if self.center is not None:
            self.center.visualize(g, max_sv, kind, min_color, max_color)
    """

    def _is_too_small(self, n_assigned, rank):
        rank_used_for_uniformity_test = min(rank, 8)
        return (n_assigned < 5) or (n_assigned < rank_used_for_uniformity_test+1)
    
    def premature_stop(self, my_x_resid: NDArray) -> bool:
        if self.rank == 1:
            print("LEAF Rank 1 ", self.n_assigned, self.rank, self.depth)
            return True

        return False
    
    def calculate(self) -> NDArray:
        self.n_assigned = int(self.mask.sum())
        my_x_resid = self._projection_residuals(self.ctx.X[self.mask])
        if isinstance(my_x_resid, str):
            self.is_leaf = True
            print("SVDERR", self.singular_value)
            return None
        try:
            U, s, VT = LA.svd(my_x_resid, full_matrices=False)
        except:
            self.is_leaf = True
            self.singular_value = LA.eigvals(my_x_resid.T @ my_x_resid)[0]
            self.resid_sum_squares = self.parent.resid_sum_squares
            return "ERROR"
        
        self.rank = (s > 1e-7).sum()
        self.singular_value = s[0]
        self.basis_vector = VT[0]
        self.resid_sum_squares = (LA.norm(my_x_resid, axis=1)**2).sum()

        if self.premature_stop(my_x_resid):
            self.is_leaf = True
            return None
        return my_x_resid
    
    def leaf_die(self) -> bool:
        # returns true if by removing this leaf node, the total number of leaves decreases.
        if self.parent is None:
            return True
        
        if not self.is_leaf:
            print("Woah there Buckeroo")
            return
        
        is_par_left = self.parent.left is not None
        is_par_center = self.parent.center is not None
        is_par_right = self.parent.right is not None
        
        parent_has_other_children = np.sum([is_par_left, is_par_center, is_par_right]) >= 2
        if not parent_has_other_children:
            self.parent.is_leaf = True
        if self.parent.left == self:
            self.parent.left = None
        if self.parent.center == self:
            self.parent.center = None
        if self.parent.right == self:
            self.parent.right = None
        
        if parent_has_other_children:
            return True
        return False
    
    def split(self, given_residual):
        shared_estimation_n_sample = min(self.n_assigned, self.ctx.max_shared_sample_size)
        my_x_resid_shared_sample = random_sample(given_residual, shared_estimation_n_sample)
        is_first_shared = self.ctx.shared_axis_estimator.is_first_axis_shared(my_x_resid_shared_sample)
        if is_first_shared == "SVDERR":
            self.is_leaf = True
            return
        if is_first_shared == True:
            if self._is_too_small(self.n_assigned, self.rank - 1):
                self.is_leaf = True
                return
            self.center = SubspaceTreeNode(self, self.ctx, np.copy(self.mask))
            return
        else:
            subspace_cluster_training_n_sample = min(self.n_assigned, self.ctx.max_sscluster_sample_size)
            my_x_resid_sscluster_sample = random_sample(given_residual, subspace_cluster_training_n_sample)
            self.ctx.subspace_clusterer.fit(my_x_resid_sscluster_sample)
            partition = self.ctx.subspace_clusterer.predict(given_residual)
            left_mask = sub_mask(self.mask, partition == 0)
            right_mask = sub_mask(self.mask, partition == 1)

            right = SubspaceTreeNode(self, self.ctx, right_mask)
            left = SubspaceTreeNode(self, self.ctx, left_mask)
            right_is_too_small = self._is_too_small(right_mask.sum(), self.rank-1)
            left_is_too_small = self._is_too_small(left_mask.sum(), self.rank-1)
            if left_is_too_small and right_is_too_small:
                self.is_leaf = True
                return

            if not right_is_too_small:
                self.right = right
            if not left_is_too_small:
                self.left = left