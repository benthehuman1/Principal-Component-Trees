import numpy as np
import numpy.linalg as LA
from numpy.typing import NDArray
from scipy.stats import multivariate_normal, ortho_group, beta, entropy

def pca_whiten(X, fudge=1E-4):
    # the matrix X should be observations-by-components

   # get the covariance matrix
   Xcov = np.dot(X.T,X)

   # eigenvalue decomposition of the covariance matrix
   d, V = np.linalg.eigh(Xcov)

   # a fudge factor can be used so that eigenvectors associated with
   # small eigenvalues do not get overamplified.
   D = np.diag(1. / np.sqrt(d+fudge))

   # whitening matrix
   W = np.dot(np.dot(V, D), V.T)

   # multiply by the whitening matrix
   X_white = np.dot(X, W)

   return X_white, W

def abs_cosine_similarity(X):
    X_norm = X / LA.norm(X, axis=1)[:, np.newaxis]
    return np.abs(X_norm @ X_norm.T)

def pca_whiten_random(X, fudge=1E-10):
   n, dim = X.shape

   R = multivariate_normal(np.zeros(dim), np.eye(dim)).rvs(n)
   Rcov = np.dot(R.T, R)
   d_r, _ = np.linalg.eigh(Rcov)

    # the matrix X should be observations-by-components

   # get the covariance matrix
   Xcov = np.dot(X.T,X)
   d, V = np.linalg.eigh(Xcov)

   # a fudge factor can be used so that eigenvectors associated with
   # small eigenvalues do not get overamplified.
   new_D = (((d_r**0.5) / (n**0.5)) / np.sqrt(d))
   D = np.diag(new_D)

   # whitening matrix
   W = np.dot(np.dot(V, D), V.T)

   # multiply by the whitening matrix
   X_white = np.dot(X, W)

   return X_white, W

def mode(x):
    uniq, counts = np.unique(x, return_counts=True)
    return uniq[counts.argmax()]

def my_inv_entropy(x):
    uniq, counts = np.unique(x, return_counts=True)
    n_unique = len(uniq)
    if n_unique == 1:
        return 1
    max_entropy = entropy(np.ones(n_unique) / n_unique)
    pqrt = entropy(counts / counts.sum())
    return 1 - (pqrt / max_entropy)

def sub_mask(M: NDArray, m_sub: NDArray):
    # M and m_sub are boolean arrays.
    # length of m_sub is sum of M
    assert M.sum() == len(m_sub)
    r = np.zeros(len(M), dtype=bool)
    r[np.where(M)[0][m_sub]] = True
    return r

def random_sample(X: NDArray, take: int):
    inds = np.arange(X.shape[0])
    np.random.shuffle(inds)
    return X[inds[:take]]