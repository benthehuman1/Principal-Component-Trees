import numpy as np
from scipy.stats import beta

def anderson_darling_stat(true_cdf, data):
    n = len(data)
    outer_factor = ((2*(np.arange(n) + 1))-1) / n
    true_cdf_at_sorted_data = true_cdf(np.sort(data))
    true_cdf_at_sorted_data_reversed = np.flip(true_cdf_at_sorted_data)
    try:
        inner_factor = np.log(true_cdf_at_sorted_data) + np.log(1-true_cdf_at_sorted_data_reversed)
    except:
        return np.inf

    stat = np.sum(outer_factor*inner_factor)
    return (-n) - stat

def abs_angle_cdf_gen(dim: int):
    rv = beta((dim-1)/2, (dim-1)/2)
    def cdf(x):
        # x [0, 1]
        scaled_c = (1+x)/2
        return (rv.cdf(scaled_c) * 2) - 1
    return cdf