import numpy as np
import numpy.linalg as LA
from numpy.typing import NDArray
from uniformity_tester import DirectionalUniformityTester, CachedDirectionalUniformityTester
from utils import abs_cosine_similarity, pca_whiten, pca_whiten_random, random_sample
from hypothesis_testing import abs_angle_cdf_gen, anderson_darling_stat
from sklearn.cluster import AgglomerativeClustering
from scipy.stats import ks_1samp
from scipy.interpolate import CubicSpline

class SharedAxisEstimator:
    def __init__(self):
        pass

    def is_first_axis_shared(self, X: NDArray) -> bool:
        pass

class SubspaceClusterer:
    def __init__(self) -> None:
        pass

    def fit(self, X: NDArray) -> None:
        pass

    def predict(self, X: NDArray) -> NDArray:
        pass

class SSHAVESEstimator(SharedAxisEstimator):
    def __init__(self, uniformity_tester: DirectionalUniformityTester, alpha: str = "0.01", max_escavation_depth: int = 8, significant_test_increase: float = 1.1):
        super().__init__()
        self.uniformity_tester = uniformity_tester
        self.alpha = alpha
        self.max_escavation_depth = max_escavation_depth
        self.significant_test_increase = significant_test_increase # 1.0+

    def is_first_axis_shared(self, X: NDArray) -> bool:
        # new thing.... pass in the whitened data?
        given_n, given_dim = X.shape

        # use rank instead of ambient_dim. The amb_dim may be 10, but maybe weve already done 6 layers of projection.
        try:
            U, s, VT = LA.svd(X, full_matrices=False)
        except:
            print("SVDERR", X.shape)
            return "SVDERR"
        rank = (s > 1e-7).sum()
        
        depth = min(rank-1, self.max_escavation_depth)
        if rank == 2:
            reject_uniform, test_stat_1 = self.uniformity_tester.significance_test(U[:, :2], self.alpha)
            if not reject_uniform:
                return True
            else: 
                return False

        reject_uniform, test_stat_1 = self.uniformity_tester.significance_test(U[:, :depth], self.alpha)
        if U[:, :depth].shape[1] <= 1:
            print("U 2 smol")
        if not reject_uniform:
            return True
        if reject_uniform and rank == 2:
            return False
        _, test_stat_2 = self.uniformity_tester.significance_test(U[:, 1:1+depth], self.alpha)
        if U[:, 1:1+depth].shape[1] <= 1:
            print("U 3 smol")

        test_stat_significantly_increased = (test_stat_2 / test_stat_1) >= self.significant_test_increase
        return test_stat_significantly_increased

class HACSubspaceClusterer(SubspaceClusterer):
    def __init__(self) -> None:
        super().__init__()
        self.training_points_unit: NDArray = None
        self.training_points_assignments: NDArray = None

    def fit(self, X: NDArray):
        # just to be expicit: right now we are using this multiple times... really should be a gen situation.
        self.training_points_unit: NDArray = None
        self.training_points_assignments: NDArray = None
        self.training_points_unit = X / LA.norm(X, axis=1)[:, np.newaxis]
        clusterer = AgglomerativeClustering(n_clusters=2, affinity="euclidean", linkage="average")
        abs_cosine_sim = abs_cosine_similarity(X)
        self.training_points_assignments = clusterer.fit_predict(abs_cosine_sim)
        del clusterer

    def predict(self, X: NDArray):
        X_unit = X / LA.norm(X, axis=1)[:, np.newaxis]
        cosine_sim_to_training_points = np.abs(X_unit @ self.training_points_unit.T)
        nearest_training_points = cosine_sim_to_training_points.argmax(axis=1)
        return self.training_points_assignments[nearest_training_points]

class HACSubspaceClusterer2(SubspaceClusterer):
    def __init__(self) -> None:
        super().__init__()
        #self.training_points_unit: NDArray = None
        #self.training_points_assignments: NDArray = None
        self.v1: NDArray = None
        self.v2: NDArray = None

    def fit(self, X: NDArray):
        # just to be expicit: right now we are using this multiple times... really should be a gen situation.
        self.training_points_unit: NDArray = None
        self.training_points_assignments: NDArray = None
        X_white, _, _ = LA.svd(X, full_matrices=True)
        X_norm = X_white / LA.norm(X_white, axis=1)[:, np.newaxis]
        clusterer = AgglomerativeClustering(n_clusters=2, affinity="euclidean", linkage="average")
        abs_cosine_sim = abs_cosine_similarity(X_norm)
        assignments = clusterer.fit_predict(abs_cosine_sim)
        U1, s1, VT1 = LA.svd(X[assignments == 0], full_matrices=True)
        U2, s2, VT2 = LA.svd(X[assignments == 1], full_matrices=True)
        self.v1 = np.array([VT1[0]]).T 
        self.v2 = np.array([VT2[0]]).T


    def predict(self, X: NDArray):
        #X_unit = X / LA.norm(X, axis=1)[:, np.newaxis]
        #cosine_sim_to_training_points = np.abs(X_unit @ self.training_points_unit.T)
        #nearest_training_points = cosine_sim_to_training_points.argmax(axis=1)
        #return self.training_points_assignments[nearest_training_points]
        c1 = np.abs(np.dot(X, self.v1))
        c2 = np.abs(np.dot(X, self.v2))
        return (c1 < c2).astype(int).T[0]

def binary_subspace_assigments(X, v1, v2):
    c1 = np.abs(np.dot(X, v1))
    c2 = np.abs(np.dot(X, v2))
    return (c1 < c2).astype(int)

def binary_subspace_eval(X, v1, v2, assignments):
    sum1 = (np.dot(X[assignments==0], v1)**2).sum()
    sum2 = (np.dot(X[assignments==1], v2)**2).sum()
    return sum1 + sum2

def binary_subspace_clustering(X: NDArray, iters = 10):
    N = X.shape[0]
    v1 = X[np.random.randint(0, N)]
    v1 = v1 / LA.norm(v1)
    v2 = X[np.random.randint(0, N)]
    v2 = v2 / LA.norm(v2)
    curr_assignments = binary_subspace_assigments(X, v1, v2)
    for i in range(iters):
        #print(binary_subspace_eval(X, v1, v2, curr_assignments))
        _, _, VT1 = LA.svd(X[curr_assignments==0], full_matrices=False)
        _, _, VT2 = LA.svd(X[curr_assignments==1], full_matrices=False)
        v1 = VT1[0]
        v2 = VT2[0]
        curr_assignments = binary_subspace_assigments(X, v1, v2)

    return curr_assignments, v1, v2

class KSubspaceClusterer(SubspaceClusterer):
    def __init__(self) -> None:
        super().__init__()
        #self.training_points_unit: NDArray = None
        #self.training_points_assignments: NDArray = None
        self.v1: NDArray = None
        self.v2: NDArray = None

    def fit(self, X: NDArray):
        # just to be expicit: right now we are using this multiple times... really should be a gen situation.
        self.training_points_unit: NDArray = None
        self.training_points_assignments: NDArray = None
        #X_white, _, _ = LA.svd(X, full_matrices=True)
        X_norm = X / LA.norm(X, axis=1)[:, np.newaxis]
        assignments, self.v1, self.v2 = binary_subspace_clustering(X_norm, iters = 6)
        return assignments

    def predict(self, X: NDArray):
        #X_unit = X / LA.norm(X, axis=1)[:, np.newaxis]
        #cosine_sim_to_training_points = np.abs(X_unit @ self.training_points_unit.T)
        #nearest_training_points = cosine_sim_to_training_points.argmax(axis=1)
        #return self.training_points_assignments[nearest_training_points]
        c1 = np.abs(np.dot(X, self.v1))
        c2 = np.abs(np.dot(X, self.v2))
        return (c1 < c2).astype(int)

class ADADTester(CachedDirectionalUniformityTester):
    # ADAD: Anderson Darling on Angle Distribution
    def __init__(self, test_stat_table: dict[int, dict[int, dict[int, float]]]):
        super().__init__(test_stat_table)

    def calculate_test_stat(self, X: NDArray) -> float:
        # Idea, there is randomness in pca_whiten_random..... take average of a few stats??
        n, dim = X.shape
        true_cdf = abs_angle_cdf_gen(dim)
        mask = ~np.tri(n, n, dtype=bool)
        X_soft_whitened, W = pca_whiten_random(X)
        pairwise_similarities = abs_cosine_similarity(X_soft_whitened)[mask]
        return anderson_darling_stat(true_cdf, pairwise_similarities)
        # make no assumptions about X ,don't center though? 


def n_set():
    num_samples = list(np.arange(5, 21)) # 2 --> 21
    num_samples.extend(list(np.round(21 * np.power(1.05, np.arange(100))).astype(int)))
    return np.array(num_samples)[:63]

def big_n_set():
    num_samples = list(np.arange(5, 21)) # 2 --> 21
    num_samples.extend(list(np.round(20 * np.power(1.05, np.arange(100))).astype(int)))
    return np.array(num_samples)

def abs_whit_angle_cdf_gen(n: int, amb_dim: int):
    with open(f"white_angle_cdfs_cubic/d{amb_dim}_n{n}.npy", "rb") as f:
        cdf_points = np.load(f)
    def result(x):
        return np.interp(x, xp=cdf_points[0], fp=cdf_points[1])
    return result

class WhitenedADADTester_MonteCarlo(CachedDirectionalUniformityTester):
    # ADAD: Anderson Darling on Angle Distribution
    def __init__(self, test_stat_table: dict[int, dict[int, dict[int, float]]]):
        super().__init__(test_stat_table)

    def calculate_test_stat(self, X: NDArray) -> float:
        # Idea, there is randomness in pca_whiten_random..... take average of a few stats??
        n, dim = X.shape
        my_n_set = big_n_set()
        chosen_n = my_n_set[np.where(my_n_set[my_n_set <= n])[0][-1]]
        X_chosen = random_sample(X, chosen_n)
        monte_carlo_cdf = abs_whit_angle_cdf_gen(chosen_n, dim)
        mask = ~np.tri(chosen_n, chosen_n, dtype=bool)
        try:
            X_soft_whitened, _, _ = LA.svd(X_chosen, full_matrices=False) # this is where the whitening happens
        except:
            print(X_chosen.shape)
        pairwise_similarities = abs_cosine_similarity(X_soft_whitened)[mask]
        return anderson_darling_stat(monte_carlo_cdf, pairwise_similarities)
    
class KSADTester(DirectionalUniformityTester):
    def __init__(self, ) -> None:
        super().__init__()

    def significance_test(self, X_white: NDArray, alpha: str) -> tuple[bool, float]:
        # new pre-req: X Must be pre-whitened... already satisfied?
        alpha_num = float(alpha)
        n, dim = X_white.shape
        my_n_set = big_n_set()
        chosen_n = my_n_set[np.where(my_n_set[my_n_set <= n])[0][-1]]
        X_chosen = random_sample(X_white, chosen_n)
        monte_carlo_cdf = abs_whit_angle_cdf_gen(chosen_n, dim) # expexted
        mask = ~np.tri(chosen_n, chosen_n, dtype=bool)
        #try:
        #    X_soft_whitened, _, _ = LA.svd(X_chosen, full_matrices=False) # this is where the whitening happens
        #except:
        #    print(X_chosen.shape)
        pairwise_similarities = abs_cosine_similarity(X_chosen)[mask] # observed
        test_result = ks_1samp(pairwise_similarities, monte_carlo_cdf, alternative="greater", method="exact")
        return test_result.pvalue < alpha_num, test_result.statistic


    
    